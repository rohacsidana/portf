import ciklus_while
#ciklus_while.fl5()
ciklus_while.fl9()